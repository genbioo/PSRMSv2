#ifndef __OUTPUT_FORMAT_H__
#define __OUTPUT_FORMAT_H__


#include <cstringt.h>

CString makeUserFriendlyString(__int64 val);


#endif // #ifndef __OUTPUT_FORMAT_H__

